# eCommerce-website-using-HTML-CSS-JS-PHP-and-MySQLi-database
This is an eCommerce website designed using HTML, CSS, JS, Bootstrap, PHP and integrated with MySQLi database. The information of all users, items as well as the items purchased by each user will be stored securely in the database. 
Xampp server should be on, in order to run the website on your local computer.

Steps to Run the Website:
->Create a folder named ecommerce and within that folder, create a folder img, and paste all images in this folder.
->Next, create a folder css and add all .css files in it. Then, create a folder fonts and add all fonts used(glyphicons) files in it.
->Create a folder js, and add all .js files.
->Finally create a folder includes and add check-if-added.php, common.php, header.php and footer.php into it.
->In your browser, type localhost/ecommerce/index.php
->the website will open and you can test the working.

This is the YouTube Link:https://www.youtube.com/watch?v=v7cxHz1FFng
